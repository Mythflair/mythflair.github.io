# 紫塞 Hugo / PaperMod 摄影画廊套件

## 文件安装

将 `layouts/shortcodes/gallery.html`、`assets/css/extended/gallery.css`、`static/js/gallery.js` 复制到 Hugo 项目根目录下的同名路径。

将示例文章 `content/photography/winter-snow-2026/index.md` 复制到项目，图片放入同级 `photos/` 文件夹，命名 `001.webp` 至 `060.webp`。示例文章 `draft: true`，校验后再改为 `false`。

如果已有 `photography` 目录或相同文件名，请先对比再合并，不要覆盖现有内容。

## 使用

文章里写 `{{< gallery >}}`，自动读取当前 Page Bundle 的 `photos/*.webp`。可用于任意其他 Page Bundle。

本套件依赖 PaperMod 自动加载 `assets/css/extended/*.css` 的约定；若自定义主题删除了该加载机制，需要自行在主题样式入口导入 CSS。

## 运行验证

1. 确认使用 Hugo extended，并且内容以 `index.md` 为 Page Bundle 根。
2. `hugo server -D` 进行本地预览。
3. 确认相册图片显示、手机2列、点击放大、方向键切换、Esc关闭、懒加载、浏览器控制台无错误。
4. `hugo --minify --printI18nWarnings --printPathWarnings --panicOnWarning` 进行与生产一致的构建检查。
5. 公开发布前确认授权和署名；将 `draft` 改为 `false`。

## 说明

- 图像由 Hugo 构建时生成 900×1200 盒内缩略图与 1800×1800 盒内大图（始终保留原比例，不放大），浏览器灯箱加载大图。
- 相册采用 CSS columns 形成瀑布流，视觉阅读顺序按列从上至下；不是严格按横向一行一行从左到右排列。
- 默认 alt 使用序号描述，正式发布时建议针对重点照片扩展为逐图准确描述。
- Page Bundle 的第一张照片不会自动成为 PaperMod 文章封面。如需列表页封面，在 front matter 指定 `cover.image: "photos/001.webp"` 并检查当前主题行为。
- 不建议上传聊天软件压缩过度的缩略图作为摄影原片；优先索取摄影师授权的高清版。
