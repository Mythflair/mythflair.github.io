(() => {
  function initGallery(root) {
    const buttons = [...root.querySelectorAll('[data-gallery-open]')];
    const dialog = root.querySelector('.zisai-gallery__dialog');
    const image = root.querySelector('[data-gallery-large]');
    const counter = root.querySelector('[data-gallery-count]');
    if (!buttons.length || !dialog || !image || !counter) return;

    let currentIndex = 0;
    let previousFocus = null;

    function show(index) {
      currentIndex = (index + buttons.length) % buttons.length;
      const button = buttons[currentIndex];
      image.src = button.dataset.full;
      image.alt = button.dataset.alt || '';
      counter.textContent = `${currentIndex + 1} / ${buttons.length}`;
    }

    buttons.forEach((button, index) => {
      button.addEventListener('click', () => {
        if (typeof dialog.showModal !== 'function') return;
        previousFocus = document.activeElement;
        show(index);
        dialog.showModal();
      });
    });

    root.querySelector('[data-gallery-prev]').addEventListener('click', () => show(currentIndex - 1));
    root.querySelector('[data-gallery-next]').addEventListener('click', () => show(currentIndex + 1));
    root.querySelector('[data-gallery-close]').addEventListener('click', () => dialog.close());

    dialog.addEventListener('click', (event) => {
      if (event.target === dialog) dialog.close();
    });
    dialog.addEventListener('keydown', (event) => {
      if (event.key === 'ArrowLeft') { event.preventDefault(); show(currentIndex - 1); }
      if (event.key === 'ArrowRight') { event.preventDefault(); show(currentIndex + 1); }
    });
    dialog.addEventListener('close', () => {
      image.removeAttribute('src');
      if (previousFocus && typeof previousFocus.focus === 'function') previousFocus.focus();
    });
  }

  function init() { document.querySelectorAll('[data-gallery]').forEach(initGallery); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
